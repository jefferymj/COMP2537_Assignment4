# Step 1. Setup the files and the imports
# Step 2. Create Six cards. Add two images inside each card; front and back in each card. have the cards inside a flex box.
# Step 3. Overlap the front and the back of each card so that only the back of the cards are visible.
# Step 4. Add a flip animation to the cards on hover.
# Step 4.1 Add the flip class to rotateY(180deg) to the .card:hover and transition in 1s
# Step 4.2 Make the rotation in 3d by adding perspective: 1000px; to the .card
# Step 5. Check if two cards are the same.
# Step 6a If two cards are not the same, flip them back
# Step 6b If two cards are not the same, flip them back with some 
# Step 7. If two cards are the same, remove them from the game.